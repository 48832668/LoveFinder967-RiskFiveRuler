RiskFiveRuler 26.11.12 - Windows x64 便携版
==========================================

【怎么运行】
1. 先把整个文件夹解压到一个「可写」目录，例如 D:\Tools\RiskFiveRuler。
   不要放在 C:\Program Files，也不要直接在压缩软件里双击 exe。
2. 双击 RiskFiveRuler.exe 即可，不需要任何启动脚本或安装步骤。
3. 免安装、不写注册表；不想要了直接删掉整个文件夹。

【系统要求】
- Windows 10 1803 / Windows Server 2019 及以上，或 Windows 11，64 位。
- 需要 Microsoft Edge WebView2 Runtime（Win10/11 一般随 Edge 自带）。
  若启动提示缺少 WebView2，请安装「常青版运行时」：
  https://developer.microsoft.com/microsoft-edge/webview2/
- 不需要 Node.js、.NET 或额外 VC++ 运行库；UCRT 是 Win10+ 系统自带组件。

【文件说明】
RiskFiveRuler.exe    主程序，前端资源已内嵌，不依赖 dev server
WebView2Loader.dll   WebView2 加载器，必须与 exe 同目录，不可单独移动或删除
                     （exe 对它属于静态导入，缺了会直接无法启动）
BUILD-INFO.txt       本次构建信息与文件校验值
README-Windows.txt   本说明
config.json          本包不含。首次启动由程序用默认值自动创建，保存主题色 /
                     明暗模式 / 新手模式 / 引脚配色。可复制、手改，设置界面
                     里也能导入、导出。默认值大致如下：
                     {
                       "version": 1,
                       "themeColor": "#008dd7",
                       "mode": "dark",
                       "beginner": true,
                       "pinColors": {}
                     }

【常见问题】
Q: 提示找不到 WebView2Loader.dll，或双击后没反应
A: 确认 dll 与 exe 在同一目录；确认是从 zip 完整解压出来的。

Q: 目录里没有生成 config.json
A: 多半是解压到了只读目录或权限不足。程序会自动退回内存默认值，
   不影响使用；换个可写目录即可。

Q: 杀毒软件报毒
A: 便携 exe 未做数字签名，属于常见误报。请以 SHA256SUMS.txt 中的
   SHA-256 校验值核对文件完整性，不要校验通过后再被替换。

【仓库】
Gitee  https://gitee.com/LoveFinderSeriesOfficial/LoveFinder967-RiskFiveRuler
GitHub https://github.com/48832668/LoveFinder967-RiskFiveRuler
